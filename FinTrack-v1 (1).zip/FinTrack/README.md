# FinTrack

**Take control of your money.**

FinTrack is a responsive personal finance tracker demo. It helps users record income and expenses, review a simple spending breakdown, and track savings goals.

## Features

- Add income and expense transactions in Kazakhstani tenge (₸)
- Automatically calculate total balance, income, and expenses
- View a spending breakdown by category
- Create savings goals and track progress
- Delete transactions
- Responsive Dark Premium interface with optional light theme
- Save data in browser `localStorage`

## Tech stack

- HTML5
- CSS3
- Vanilla JavaScript
- Chart.js (loaded from CDN)

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.

For the best development experience, use the VS Code **Live Server** extension and open `index.html` with Live Server.

## Project structure

```text
FinTrack/
├── index.html
├── style.css
├── script.js
├── README.md
├── assets/
└── screenshots/
```

## Data and privacy

This is an educational demo. Data is stored locally in the browser that you use. Clearing browser site data may erase it. The app does **not** connect to banks, process payments, or provide financial advice. Do not enter bank passwords, card numbers, or other sensitive information.

## Roadmap

- [ ] Edit existing transactions
- [ ] Monthly filters and reports
- [ ] Export transactions to CSV
- [ ] Add recurring transactions
- [ ] Backend API and database
- [ ] User accounts and authentication

## License

MIT — see `LICENSE`.
