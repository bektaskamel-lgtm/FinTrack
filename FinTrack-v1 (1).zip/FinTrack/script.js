const STORAGE_KEY = "fintrack-data-v1";
const money = new Intl.NumberFormat("kk-KZ", { maximumFractionDigits: 0 });
const formatMoney = value => "₸" + money.format(value);

const defaultData = { transactions: [], goals: [] };
let data = loadData();
let chart;

function loadData() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved && Array.isArray(saved.transactions) && Array.isArray(saved.goals) ? saved : structuredClone(defaultData);
  } catch {
    return structuredClone(defaultData);
  }
}
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
function totals() {
  const income = data.transactions.filter(t => t.type === "income").reduce((sum, t) => sum + t.amount, 0);
  const expenses = data.transactions.filter(t => t.type === "expense").reduce((sum, t) => sum + t.amount, 0);
  return { income, expenses, balance: income - expenses };
}
function renderStats() {
  const t = totals();
  document.getElementById("balanceValue").textContent = formatMoney(t.balance);
  document.getElementById("incomeValue").textContent = formatMoney(t.income);
  document.getElementById("expenseValue").textContent = formatMoney(t.expenses);
}
function renderTransactions(showAll = false) {
  const tbody = document.getElementById("transactionRows");
  const sorted = [...data.transactions].sort((a,b) => b.date.localeCompare(a.date) || b.id - a.id);
  const rows = showAll ? sorted : sorted.slice(0, 5);
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty-row">No transactions yet. Add your first one.</td></tr>';
    return;
  }
  const symbols = { Food:"⌁", Transport:"↗", Shopping:"◇", Education:"▤", Entertainment:"♫", Health:"＋", Salary:"↙", Other:"•" };
  tbody.innerHTML = rows.map(t => `
    <tr>
      <td><div class="transaction-name"><span class="transaction-icon">${symbols[t.category] || "•"}</span>${escapeHTML(t.name)}</div></td>
      <td><span class="category-tag">${escapeHTML(t.category)}</span></td>
      <td>${new Date(t.date + "T12:00:00").toLocaleDateString("ru-RU", {day:"2-digit", month:"short", year:"numeric"})}</td>
      <td class="${t.type === "income" ? "amount-income" : "amount-expense"}">${t.type === "income" ? "+" : "−"}${formatMoney(t.amount)}</td>
      <td><button class="delete-button" data-delete="${t.id}" aria-label="Delete transaction">×</button></td>
    </tr>`).join("");
}
function renderBreakdown() {
  const expenses = data.transactions.filter(t => t.type === "expense");
  const total = expenses.reduce((sum,t) => sum + t.amount, 0);
  const groups = {};
  expenses.forEach(t => groups[t.category] = (groups[t.category] || 0) + t.amount);
  const entries = Object.entries(groups).sort((a,b) => b[1] - a[1]);
  const container = document.getElementById("categoryBreakdown");
  if (!entries.length) {
    container.innerHTML = '<div class="empty-state">Add an expense to see your breakdown.</div>';
    return;
  }
  container.innerHTML = entries.slice(0,5).map(([name, amount]) => {
    const percent = total ? Math.round(amount / total * 100) : 0;
    return `<div class="breakdown-item"><div class="breakdown-label"><span>${escapeHTML(name)}</span><span>${formatMoney(amount)} · ${percent}%</span></div><div class="bar-track"><div class="bar-fill" style="width:${percent}%"></div></div></div>`;
  }).join("");
}
function renderGoals() {
  const container = document.getElementById("goalsList");
  if (!data.goals.length) {
    container.innerHTML = '<div class="empty-state">Your next big thing starts with a goal.</div>';
    return;
  }
  container.innerHTML = data.goals.map(g => {
    const percent = Math.min(100, Math.round(g.saved / g.target * 100));
    return `<div class="goal-card"><div class="goal-top"><strong>${escapeHTML(g.name)}</strong><span class="goal-percent">${percent}%</span></div><div class="goal-amounts">${formatMoney(g.saved)} saved of ${formatMoney(g.target)}</div><div class="goal-progress"><div style="width:${percent}%"></div></div></div>`;
  }).join("");
}
function renderChart() {
  const canvas = document.getElementById("cashflowChart");
  if (!window.Chart) {
    canvas.parentElement.innerHTML = '<div class="empty-state">Chart library could not load. Check your internet connection.</div>';
    return;
  }
  const income = data.transactions.filter(t => t.type === "income").reduce((s,t) => s+t.amount, 0);
  const expenses = data.transactions.filter(t => t.type === "expense").reduce((s,t) => s+t.amount, 0);
  if (chart) chart.destroy();
  chart = new Chart(canvas, {
    type: "bar",
    data: {
      labels: ["Income", "Expenses"],
      datasets: [{
        data: [income, expenses],
        backgroundColor: ["#b7f36b", "#617e67"],
        borderRadius: 7,
        borderSkipped: false,
        barThickness: 38
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => formatMoney(ctx.raw) } } },
      scales: {
        x: { grid: { display: false }, ticks: { color: "#9aa69d", font: { family: "DM Sans" } }, border: { display: false } },
        y: { beginAtZero: true, grid: { color: "rgba(135,147,139,.12)" }, ticks: { color: "#718078", callback: value => value >= 1000 ? (value/1000)+"k" : value, font: { family: "DM Sans", size: 10 } }, border: { display: false } }
      }
    }
  });
}
function render() {
  renderStats(); renderTransactions(); renderBreakdown(); renderGoals(); renderChart();
  saveData();
}

const transactionModal = document.getElementById("transactionModal");
const goalModal = document.getElementById("goalModal");
document.getElementById("todayLabel").textContent = new Date().toLocaleDateString("ru-RU", { day:"numeric", month:"long", year:"numeric" });
document.getElementById("transactionDate").value = new Date().toISOString().slice(0,10);

document.getElementById("openModal").addEventListener("click", () => transactionModal.showModal());
document.getElementById("closeModal").addEventListener("click", () => transactionModal.close());
document.getElementById("addGoalButton").addEventListener("click", () => goalModal.showModal());
document.getElementById("closeGoalModal").addEventListener("click", () => goalModal.close());

document.getElementById("transactionForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const amount = Number(form.get("amount"));
  if (!Number.isSafeInteger(amount) || amount <= 0) return;
  data.transactions.push({
    id: Date.now(), name: String(form.get("name")).trim(),
    type: form.get("type"), category: form.get("category"),
    amount, date: form.get("date")
  });
  event.currentTarget.reset();
  document.getElementById("transactionDate").value = new Date().toISOString().slice(0,10);
  transactionModal.close(); render();
});
document.getElementById("goalForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const target = Number(form.get("target")), saved = Number(form.get("saved"));
  if (!Number.isSafeInteger(target) || target <= 0 || !Number.isSafeInteger(saved) || saved < 0) return;
  data.goals.push({ id: Date.now(), name: String(form.get("name")).trim(), target, saved });
  event.currentTarget.reset(); goalModal.close(); render();
});
document.getElementById("transactionRows").addEventListener("click", event => {
  const button = event.target.closest("[data-delete]");
  if (!button) return;
  data.transactions = data.transactions.filter(t => t.id !== Number(button.dataset.delete));
  render();
});
document.getElementById("viewAllButton").addEventListener("click", () => {
  const button = document.getElementById("viewAllButton");
  const expanded = button.dataset.expanded === "true";
  button.dataset.expanded = String(!expanded);
  button.innerHTML = expanded ? 'View all <span>→</span>' : 'Show less <span>↑</span>';
  renderTransactions(!expanded);
});
document.getElementById("themeButton").addEventListener("click", () => {
  document.body.classList.toggle("light");
  localStorage.setItem("fintrack-theme", document.body.classList.contains("light") ? "light" : "dark");
});
if (localStorage.getItem("fintrack-theme") === "light") document.body.classList.add("light");
render();
